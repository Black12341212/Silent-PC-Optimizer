TRANSLATIONS = {
    "ru": {
        "app_name": "Silent PC Optimizer",
        "version": "v3.0",
        "tray_tooltip": "PC Optimizer | RAM: {ram}%",
        "optimize_now": "Оптимизировать сейчас",
        "auto_mode": "Авто-режим",
        "auto_on": "Автоматическая очистка: ВКЛ",
        "auto_off": "Автоматическая очистка: ВЫКЛ",
        "autostart": "Автозапуск",
        "autostart_on": "Автозапуск включён",
        "autostart_off": "Автозапуск выключен",
        "stats": "Статистика RAM",
        "stats_title": "Использование RAM — последние {n} мин",
        "help_menu": "Справка",
        "about": "О программе",
        "about_title": "О программе",
        "about_text": (
            "Silent PC Optimizer {version}\n\n"
            "Тихий оптимизатор Windows.\n"
            "Мониторинг RAM, очистка TEMP,\n"
            "сворачивание браузеров.\n\n"
            "Автор: zenixx5678"
        ),
        "support": "Поддержать проект",
        "support_tooltip": "donationalerts.com/r/zenixx5678",
        "language": "Язык",
        "kill_processes": "Завершить тяжёлые процессы",
        "processes_title": "Фоновые процессы",
        "no_heavy": "Тяжёлых процессов не обнаружено",
        "kill_confirm": "Завершить {n} процессов?",
        "killed": "Завершено: {n} процессов",
        "exit": "Выход",
        "monitoring_started": "Мониторинг запущен",
        "tray_notification": "Работает в фоне. Правый клик для меню.",
        "optimization_notification": (
            "Освобождено RAM: {freed} ГБ\n"
            "Кэш: {cache} МБ\n"
            "Свернуто окон: {wins}"
        ),
        "ram_chart": "RAM: {ram}% | Свободно: {free} ГБ",
        "language_changed": "Язык изменён на: {lang}",
        "hibernation_warn": "ПК уйдёт в гибернацию через {sec} сек",
    },
    "en": {
        "app_name": "Silent PC Optimizer",
        "version": "v3.0",
        "tray_tooltip": "PC Optimizer | RAM: {ram}%",
        "optimize_now": "Optimize Now",
        "auto_mode": "Auto-mode",
        "auto_on": "Auto cleanup: ON",
        "auto_off": "Auto cleanup: OFF",
        "autostart": "Autostart",
        "autostart_on": "Autostart enabled",
        "autostart_off": "Autostart disabled",
        "stats": "RAM Stats",
        "stats_title": "RAM Usage — last {n} min",
        "help_menu": "Help",
        "about": "About",
        "about_title": "About",
        "about_text": (
            "Silent PC Optimizer {version}\n\n"
            "Silent Windows optimizer.\n"
            "RAM monitoring, TEMP cleanup,\n"
            "browser minimization.\n\n"
            "Author: zenixx5678"
        ),
        "support": "Support Project",
        "support_tooltip": "donationalerts.com/r/zenixx5678",
        "language": "Language",
        "kill_processes": "Kill heavy processes",
        "processes_title": "Background Processes",
        "no_heavy": "No heavy processes found",
        "kill_confirm": "Kill {n} processes?",
        "killed": "Killed: {n} processes",
        "exit": "Exit",
        "monitoring_started": "Monitoring started",
        "tray_notification": "Running in background. Right-click for menu.",
        "optimization_notification": (
            "RAM freed: {freed} GB\n"
            "Cache: {cache} MB\n"
            "Windows minimized: {wins}"
        ),
        "ram_chart": "RAM: {ram}% | Free: {free} GB",
        "language_changed": "Language changed to: {lang}",
        "hibernation_warn": "Hibernation in {sec} sec",
    }
}


def t(lang, key, **kwargs):
    text = TRANSLATIONS.get(lang, TRANSLATIONS["en"]).get(key, key)
    if kwargs:
        try:
            return text.format(**kwargs)
        except KeyError:
            return text
    return text
